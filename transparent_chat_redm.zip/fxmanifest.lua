fx_version 'cerulean'
game 'rdr3'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/index.css',
    'theme/style.css',
    'theme/shadow.js'
}

client_script 'client.lua'
