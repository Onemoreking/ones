Config = {}

-- ███╗░░░███╗░░░░░██╗██████╗░███████╗██╗░░░██╗
-- ████╗░████║░░░░░██║██╔══██╗██╔════╝██║░░░██║
-- ██╔████╔██║░░░░░██║██║░░██║█████╗░░╚██╗░██╔╝
-- ██║╚██╔╝██║██╗░░██║██║░░██║██╔══╝░░░╚████╔╝░
-- ██║░╚═╝░██║╚█████╔╝██████╔╝███████╗░░╚██╔╝░░
-- ╚═╝░░░░░╚═╝░╚════╝░╚═════╝░╚══════╝░░░╚═╝░░░
-- Discord: https://discord.gg/gHRNMDQKzb 
-- 🐶 Model แปลงร่าง
Config.TransformModel = "A_C_Coyote_01"
Config.ScaleModel = 5.0

-- ⚡ เอฟเฟกต์ฟ้าผ่า
Config.UseLightningStrike = true
Config.LightningRadius = 5
Config.LightningDamage = 50

-- 🔊 เสียง
Config.UseThunderSound = false
Config.ThunderSoundName = "Thunder"
Config.ThunderSoundSet = "MP_MISSION_COUNTDOWN_SOUNDSET"

-- ⏱ คูลดาวน์
Config.CooldownMS = 2000

-- 👮‍♂️ Permission
Config.AllowedGroup = "admin"

-- 💨 เอฟเฟกต์ Particle
Config.UseParticle = false
Config.ParticleAsset = "core"
Config.ParticleEffect = "fire_wrecked_car"
Config.ParticleSize = 1.5
