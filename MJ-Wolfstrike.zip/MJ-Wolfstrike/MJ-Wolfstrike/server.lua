
-- ███╗░░░███╗░░░░░██╗██████╗░███████╗██╗░░░██╗
-- ████╗░████║░░░░░██║██╔══██╗██╔════╝██║░░░██║
-- ██╔████╔██║░░░░░██║██║░░██║█████╗░░╚██╗░██╔╝
-- ██║╚██╔╝██║██╗░░██║██║░░██║██╔══╝░░░╚████╔╝░
-- ██║░╚═╝░██║╚█████╔╝██████╔╝███████╗░░╚██╔╝░░
-- ╚═╝░░░░░╚═╝░╚════╝░╚═════╝░╚══════╝░░░╚═╝░░░
-- Discord: https://discord.gg/gHRNMDQKzb 
local VORPcore
TriggerEvent("getCore", function(core)
    VORPcore = core
end)

local VorpInv = exports.vorp_inventory:vorp_inventoryApi()

RegisterServerEvent("thunderdog:checkPermission")
AddEventHandler("thunderdog:checkPermission", function()
    local _src = source
    local user = exports.vorp_core:GetUser(_src)
    if user and user.group == Config.AllowedGroup then
        TriggerClientEvent("thunderdog:triggerLightning", _src)
    end
end)
